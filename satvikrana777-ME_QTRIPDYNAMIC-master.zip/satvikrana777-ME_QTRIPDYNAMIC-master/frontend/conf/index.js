
const config = { backendEndpoint: "http://3.109.22.139:8082" };
export default config;
